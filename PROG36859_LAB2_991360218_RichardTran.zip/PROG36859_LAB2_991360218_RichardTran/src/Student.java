
public class Student {
private int StudentID=0;
private String Name="";
public Student(int studentID, String name) {
	super();
	StudentID = studentID;
	Name = name;
}
public int getStudentID() {
	return StudentID;
}
public void setStudentID(int studentID) {
	StudentID = studentID;
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}

}
