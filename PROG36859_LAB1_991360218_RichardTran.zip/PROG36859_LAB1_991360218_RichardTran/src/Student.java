import java.util.ArrayList;

public class Student {

	private int studentId;
	private String name;
	private String program;
	private ArrayList<String> courseList = new ArrayList();


	public Student(int studentId, String name, String program) {
		super();
		this.studentId = studentId;
		this.name = name;
		this.program = program;
	}

	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProgram() {
		return program;
	}
	public void setProgram(String program) {
		this.program = program;
	}
	public ArrayList<String> getCourseList() {
		return courseList;
	}
	public void setCourseList(ArrayList<String> courseList) {
		this.courseList = courseList;
	}

	public void addcourse(String course){
		courseList.add(course);
	}




}
