//richard tran Q2
public class Q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("This program prints numbers from 1 to 10.\n");
		for (int count = 1; count <= 10; count++)
			{

				System.out.println(count);

			}
		//A) looks exactly the same
		//B)ln stands for new line while normal print prints on the same line as the previous output.
		//C)code below:
		for (int num = 100; num >=0; num=num-5)
			{
				System.out.println(num);
			}

	}

}
