//richard tran L1Q1
public class Q1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("*********\t***\t\t*\t\t*");
		System.out.print("\n*\t*     *\t    *\t       ***\t       * *");
		System.out.print("\n*\t*    *\t     *\t      *****\t      *   *");
		System.out.print("\n*\t*    *\t     *\t        *\t     *     *");
		System.out.print("\n*\t*    *\t     *\t        *\t    *       *");
		System.out.print("\n*\t*    *\t     *\t        *\t     *     *");
		System.out.print("\n*\t*    *\t     *\t        *\t      *   *");
		System.out.print("\n*\t*     *\t    *\t        *\t       * *");
		System.out.print("\n*********\t***\t\t*\t\t*");

	}

}
