//richard tran Q3
public class Q3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double radius = 2.2;
		double volume = ( ( (4/3) * Math.PI ) * (Math.pow(radius, 3)) );
		System.out.printf("The volume of a sphere with the radius 2.2 is: %.2f", volume);
	}

}
