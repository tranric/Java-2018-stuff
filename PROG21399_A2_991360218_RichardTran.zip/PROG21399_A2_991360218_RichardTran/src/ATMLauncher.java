/**
 *
 * @author Richard Tran
 * Description Calls the methods in the ATM class
 * @version 1.0
 * @since 2018-06-04 (YYYY-MM-DD)
 */
public class ATMLauncher {
public static void main(String[] args) {
ATM atm = new ATM();
atm.run();
}
}